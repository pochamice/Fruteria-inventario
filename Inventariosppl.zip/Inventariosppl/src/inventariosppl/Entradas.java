package inventariosppl;
public class Entradas extends Movimiento {

    static void add(Entradas e) {
        
    }
    
    private int ID_Proveedor; 
    
    public Entradas(int ID_Movimiento, int ID_Producto, double Cantidad, String Concepto, String TipoMovimiento, int ID_Proveedor) {
        super(ID_Movimiento, ID_Producto, Cantidad, Concepto, TipoMovimiento);
        this.ID_Proveedor = ID_Proveedor;
    }

    public void registrarEntradas(Inventario inventario){
        obtenerMovimiento(); 
        System.out.println("ID Proveedor: " + ID_Proveedor);
        inventario.actualizarStock(this.getCantidad());
        System.out.println("Entrada registrada. Stock actualizado para el producto " + this.getID_Producto());
    }
    
    public int getID_Proveedor() {
        return ID_Proveedor;
    }
}