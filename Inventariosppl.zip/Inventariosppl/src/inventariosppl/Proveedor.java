/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariosppl;


public class Proveedor {
    int ID_Proveedor;
    int Contacto;
    String Nombre;
    
    public Proveedor(int ID_Proveedor, int Contacto, String Nombre){
    
        this.ID_Proveedor = ID_Proveedor;
        this.Contacto = Contacto;
        this.Nombre = Nombre;
}
    
    public void registrarProveedor(){
        
    }
    public void actualizarProveedor(){
        
    }
    
    
}
