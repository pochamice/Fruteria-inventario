package inventariosppl;

public class Proveedor {
    private int ID_Proveedor;
    private String Contacto; 
    private String Nombre;
    public Proveedor(int ID_Proveedor, String Contacto, String Nombre){
    
        this.ID_Proveedor = ID_Proveedor;
        this.Contacto = Contacto;
        this.Nombre = Nombre;
    }
    public void registrarProveedor(){
        System.out.println("Proveedor Registrado");
        System.out.println("ID: " + ID_Proveedor);
        System.out.println("Nombre: " + Nombre);
        System.out.println("Contacto: " + Contacto);
    }

    public void actualizarProveedor(String nuevoContacto, String nuevoNombre){
        this.Contacto = nuevoContacto;
        this.Nombre = nuevoNombre;
        System.out.println("Proveedor ID " + ID_Proveedor + " actualizado.");
        registrarProveedor(); 
    }
    public int getID_Proveedor() {
        return ID_Proveedor;
    }

    public String getContacto() {
        return Contacto;
    }
    public void setContacto(String Contacto) {
        this.Contacto = Contacto;
    }

    public String getNombre() {
        return Nombre;
    }
    
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
}