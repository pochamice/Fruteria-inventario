/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariosppl;

import java.util.ArrayList;
import java.util.List;

public class AlertaInventario {
    
    private List<Inventario> inventarios;
    double cantMin;
    
    public AlertaInventario(double cantMin){
        inventarios = new ArrayList<>();
        this.cantMin = cantMin;
        
    }
    void agregarInventario (Inventario inv) {
        inventarios.add(inv);
    }
    
    void verificarCantStock(Productos pr, Inventario in){
        if (in.ExistenciaActual <= pr.StockMin) {
            System.out.println("========================== ALERTA ==========================");
            System.out.println("El producto: " + pr.Nombre + "está por debajo de su stock minimo.");
            System.out.println("Existencia actaual: " + in.ExistenciaActual);
            System.out.println("Stock que se requiere: " + pr.StockMin);
        }
    }
    
    void generarAlerta(){
        System.out.println("============ ALERTA =============");
        for (Inventario inv : inventarios) {
            if (inv.ExistenciaActual <= cantMin) {
                System.out.println("El producto: " + inv.ID_Producto + "necesita superar la cantidad minima. ");
               
            }
        }
    }
    
}
