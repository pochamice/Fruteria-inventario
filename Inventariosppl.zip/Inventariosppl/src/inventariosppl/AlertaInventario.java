package inventariosppl;

import java.util.ArrayList;
import java.util.List;

public class AlertaInventario {
    
    private List<Inventario> inventarios;
    double cantMin;
    
    public AlertaInventario(double cantMin){
        inventarios = new ArrayList<>();
        this.cantMin = cantMin;
        
    }
    void agregarInventario (Inventario inv) {
        inventarios.add(inv);
    }
    
    void verificarCantStock(Productos pr, Inventario in){
        if (in.getExistenciaActual() <= pr.getStockMin()) {
            System.out.println("========================== ALERTA ==========================");
            System.out.println("El producto: " + pr.getNombre() + "está por debajo de su stock minimo.");
            System.out.println("Existencia actaual: " + in.getExistenciaActual());
            System.out.println("Stock que se requiere: " + pr.getStockMin());
        }
    }
    
    void generarAlerta(){
        System.out.println("============ ALERTA =============");
        for (Inventario inv : inventarios) {
            if (inv.ExistenciaActual <= cantMin) {
                System.out.println("El producto: " + inv.ID_Producto + "necesita superar la cantidad minima. ");
               
            }
        }
    }
    
}
