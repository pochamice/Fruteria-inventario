package inventariosppl;
public class Productos {
    private int ID_Producto;
    private String Nombre;
    private String UnidadMedida;
    private int ID_Proveedor;
    private static int StockMin; 
    private double PrecioVenta;
    private double PrecioCosto;
    
    public Productos(int ID_Producto, String Nombre, String UnidadMedida, int ID_Proveedor, int StockMin, double PrecioVenta, double PrecioCosto){
        
        this.ID_Producto = ID_Producto;
        this.Nombre = Nombre;
        this.UnidadMedida = UnidadMedida;
        this.ID_Proveedor = ID_Proveedor;
        this.StockMin = StockMin;
        this.PrecioVenta = PrecioVenta;
        this.PrecioCosto = PrecioCosto;
        
        
    }
    public void obtenerInfo(){
        System.out.println("=== Información del Producto ===");
        System.out.println("ID Producto: " + ID_Producto);
        System.out.println("Nombre: " + Nombre);
        System.out.println("Unidad de Medida: " + UnidadMedida);
        System.out.println("ID Proveedor: " + ID_Proveedor);
        System.out.println("Stock Mínimo: " + StockMin);
        System.out.println("Precio Venta: $" + PrecioVenta);
        System.out.println("Precio Costo: $" + PrecioCosto);
    }
    public int getID_Producto() {
        return ID_Producto;
    }
    public String getNombre() {
        return Nombre;
    }

    public String getUnidadMedida() {
        return UnidadMedida;
    }

    public int getID_Proveedor() {
        return ID_Proveedor;
    }

    public static int getStockMin() {
        return StockMin;
    }
    
    public void setStockMin(int StockMin) {
        this.StockMin = StockMin;
    }

    public double getPrecioVenta() {
        return PrecioVenta;
    }

    public void setPrecioVenta(double PrecioVenta) {
        this.PrecioVenta = PrecioVenta;
    }

    public double getPrecioCosto() {
        return PrecioCosto;
    }

    public void setPrecioCosto(double PrecioCosto) {
        this.PrecioCosto = PrecioCosto;
    }
}