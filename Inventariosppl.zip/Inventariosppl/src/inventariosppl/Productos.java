/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariosppl;


public class Productos {
    
    int ID_Producto;
    String Nombre;
    String UnidadMedida;
    int ID_Proveedor;
    static int StockMin;
    double PrecioVenta;
    double PrecioCosto;
    
    public Productos(int ID_Producto, String Nombre, String UnidadMedida, int ID_Proveedor, int StockMin, double PrecioVenta, double PrecioCosto){
        
        this.ID_Producto = ID_Producto;
        this.Nombre = Nombre;
        this.UnidadMedida = UnidadMedida;
        this.ID_Proveedor = ID_Proveedor;
        this.StockMin = StockMin;
        this.PrecioVenta = PrecioVenta;
        this.PrecioCosto = PrecioCosto;
        
    }
    
    void obtenerInfo(){
        
    }
    
    void generarLista(){
        
    }
    
}
