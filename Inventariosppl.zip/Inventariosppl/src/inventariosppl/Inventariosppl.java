/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inventariosppl;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Inventariosppl {

    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        boolean salir = false;
         
       while (!salir) {
           try{
            System.out.println("Fruteria 'f r u i t s  d e l i g h t s'");
            System.out.println("=== MENU DE INVENTARIO ===");
            System.out.println("1. Agregar datos y recibir diagnostico.");
            System.out.println("2. Salir.");
            System.out.print("Elige una opcion: ");
            
           
            int opcion = sc.nextInt();

            switch (opcion){
                
                case 1 : {
                    
                    break;
                }
                case 2: {
                    
                    break;
                }
                case 3:{
                    
                    break;
                }
                case 4:{
                    System.out.println("Adios, tenga un buen dia.");
                    salir = true;
                    break;
                }
                default: System.out.println("No es una opcion valida, intente de nuevo.");
                break;
            }
          }catch(InputMismatchException n){
              System.out.println("ERROR: el dato ingresado NO es valido: " + n);
              sc.nextLine();
        } 
      }
    }
    
}
