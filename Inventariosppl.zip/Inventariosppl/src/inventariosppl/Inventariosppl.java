package inventariosppl;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Inventariosppl {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        ArrayList<Productos> misProductos = new ArrayList<>();
        ArrayList<Inventario> miInventario = new ArrayList<>();
        ArrayList<Movimiento> historialMovimientos = new ArrayList<>();

        boolean salir = false;

        while (!salir) {
            try {
                System.out.println("Fruteria 'f r u i t s  d e l i g h t s'");
                System.out.println("=== MENU DE INVENTARIO ===");
                System.out.println("1. Registrar Producto.");
                System.out.println("2. Registrar Entrada.");
                System.out.println("3. Registrar Salida.");
                System.out.println("4. Mostrar resumen de inventario.");
                System.out.println("5. Mostrar resumen de entradas y salidas.");
                System.out.println("6. Salir.");
                System.out.print("Elige una opcion: ");

                int opcion = sc.nextInt();

                switch (opcion) {

                    case 1: {
                        System.out.println("Porfavor, ingrese los datos para registrar su Producto.");
                        System.out.println();

                        System.out.println("Ingrese ID del producto.");
                        int ID_Producto = sc.nextInt();
                        sc.nextLine();
                        System.out.println("Ingrese el nombre de producto.");
                        String Nombre = sc.nextLine();
                        System.out.println("Ingrese su unidad de medida.");
                        String UnidadMedida = sc.nextLine();
                        System.out.println("Ingrese el ID del proveedor.");
                        int ID_Proveedor = sc.nextInt();
                        System.out.print("Ingrese el Stock Mínimo requerido: ");
                        int StockMin = sc.nextInt();
                        System.out.println("Ingrese el precio de venta.");
                        double PrecioVenta = sc.nextDouble();
                        System.out.print("Ingrese el precio de costo: ");
                        double PrecioCosto = sc.nextDouble();
                        Productos nuevoProducto = new Productos(ID_Producto, Nombre, UnidadMedida, ID_Proveedor, StockMin, PrecioVenta, PrecioCosto);
                        misProductos.add(nuevoProducto);
                        
                        Inventario nuevoInventario = new Inventario(ID_Producto, 0.0, StockMin);
                        miInventario.add(nuevoInventario);
                        
                        System.out.println("Producto registrado con exito!");
                        break;
                    }
                    case 2: {
                        System.out.println("Porfavor, ingrese los datos para registrar su entrada.");
                        System.out.println();

                        System.out.println("Ingrese ID del producto para la entrada:");
                        int ID_Producto = sc.nextInt();
                        Productos productoEncontrado = null;

                        for (Productos Pro : misProductos) {
                            if (Pro.getID_Producto() == ID_Producto) {
                                productoEncontrado = Pro;
                                break;
                            }
                        }

                        if (productoEncontrado == null) {
                            System.out.println("ERROR: El producto no existe. Primero debe registrarlo (Opcion 1).");
                        } else {
                            System.out.println("Ingrese ID del movimiento.");
                            int ID_Movimiento = sc.nextInt();
                            System.out.println("Ingrese la Cantidad que va a entrar:");
                            double Cantidad = sc.nextDouble();
                            sc.nextLine();
                            System.out.println("Ingrese el Concepto:");
                            String Concepto = sc.nextLine();
                            System.out.println("Ingrese el ID del Proveedor:");
                            int ID_Proveedor = sc.nextInt();
                            String TipoMovimiento = "Entrada";
                            Entradas nuevaEntrada = new Entradas(ID_Movimiento, ID_Producto, Cantidad, Concepto, TipoMovimiento, ID_Proveedor);
                            Inventario inventarioEncontrado = null;
                            nuevaEntrada.registrarEntradas(inventarioEncontrado);
                            historialMovimientos.add(nuevaEntrada);

                            System.out.println("Entrada registrada con exito!");

                            System.out.println("Nuevo stock en Inventario: " + inventarioEncontrado.getExistenciaActual());
                        }
                        break;
                    }

                    case 3: {
                        try {
                            System.out.println("Ingrese el ID del producto que va a salir.");
                            int ID_Producto = sc.nextInt();
                            Productos productoAsociado = null;
                            Inventario inventarioEncontrado = null;
                            for (Inventario inv : miInventario) {

                                if (inv.getID_Producto() == ID_Producto) {

                                    inventarioEncontrado = inv;
                                    break;
                                }

                            }
                            for (Productos prod : misProductos) {
                                if (prod.getID_Producto() == ID_Producto) {
                                    productoAsociado = prod;
                                    break;
                                }
                            }
                            if (inventarioEncontrado == null) {
                                System.out.println("Error: El producto con ID " + ID_Producto + " no existe.");
                            } else {
                                System.out.println("Ingrese la cantidad a retirar: ");
                                double cantidad = sc.nextDouble();
                                sc.nextLine();

                                if (cantidad > inventarioEncontrado.getExistenciaActual()) {
                                    System.out.println("Error: No hay suficiente stock para realizar esta salida.");
                                } else if (cantidad <= 0) {
                                    System.out.println("Error: La cantidad debe ser mayor a 0.");
                                } else {

                                    System.out.println("Ingrese el concepto: ");
                                    String concepto = sc.nextLine();

                                    double nuevoStockCalculado = inventarioEncontrado.getExistenciaActual() - cantidad;
                                    inventarioEncontrado.modificar(nuevoStockCalculado);
                                    int idMovimientoAuto = historialMovimientos.size() + 1;
                                    Salidas nuevaSalida = new Salidas(idMovimientoAuto, ID_Producto, cantidad, concepto, "Salida", 0);
                                    historialMovimientos.add(nuevaSalida);
                                    System.out.println("Salida registrada.");
                                    
                                    AlertaInventario alertaSystem = new AlertaInventario(0);
                                    alertaSystem.verificarCantStock(productoAsociado, inventarioEncontrado);
                                }

                            }
                        } catch (java.util.InputMismatchException e) {

                            System.out.println("Error: esto no es valido: " + e.getMessage());
                            sc.nextLine();
                        }

                        break;
                    }
                    case 4: {
                        
                        ReporteInventario reporteInv = new ReporteInventario();
                        for(Inventario inv : miInventario){
                            reporteInv.agregarInventario(inv);
                            reporteInv.generarReporte();
                        }
                        break;
                    }
                    case 5: {
                        ReporteMovimientos reporteMov = new ReporteMovimientos();
                        for(Movimiento mov : historialMovimientos){
                            if(mov instanceof Entradas entradas){
                                reporteMov.agregarEntrada(entradas);
                            }else if(mov instanceof Salidas salidas){
                                reporteMov.agregarSalida(salidas);
                            }
                            
                        }
                        reporteMov.generarReporte();
                        break;
                    }
                    case 6: {
                        System.out.println("Adios, tenga un buen dia.");
                        salir = true;
                        break;
                    }
                    default:
                        System.out.println("No es una opcion valida, intente de nuevo.");
                        break;
                }
            } catch (InputMismatchException n) {
                System.out.println("ERROR: el dato ingresado NO es valido: " + n);
                sc.nextLine();
            }
        }
    }

}
