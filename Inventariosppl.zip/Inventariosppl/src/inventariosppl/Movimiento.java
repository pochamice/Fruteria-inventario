package inventariosppl;
import java.time.LocalDateTime;
public class Movimiento {
    private int ID_Movimiento;
    private int ID_Producto;
    private double Cantidad;
    private String Concepto;
    private LocalDateTime fecha;
    private String TipoMovimiento;
    
    public Movimiento(int ID_Movimiento, int ID_Producto, double Cantidad, String Concepto, String TipoMovimiento){
        
        this.ID_Movimiento = ID_Movimiento;
        this.ID_Producto = ID_Producto;
        this.Cantidad = Cantidad;
        this.Concepto = Concepto;
        this.fecha = LocalDateTime.now();
        this.TipoMovimiento = TipoMovimiento;
        
    }
    public void obtenerMovimiento(){
        System.out.println("Detalles del Movimiento:");
        System.out.println("ID Movimiento: " + ID_Movimiento);
        System.out.println("ID Producto: " + ID_Producto);      
        System.out.println("Cantidad: " + Cantidad);
        System.out.println("Concepto: " + Concepto);
        System.out.println("Fecha: " + fecha);
        System.out.println("Tipo de Movimiento: " + TipoMovimiento);
        
    }

    public int getID_Movimiento() {
        return ID_Movimiento;
    }

    public String getTipoMovimiento() {
        return TipoMovimiento;
    }
    
    public int getID_Producto() {
        return ID_Producto;
    }
    public double getCantidad() {
        return Cantidad;
    }
    
    public String getConcepto() {
        return Concepto;
    }
    public LocalDateTime getFecha() {
        return fecha;
    }   
    
}

