/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariosppl;

import java.time.LocalDateTime;
import java.util.Date;


public class Movimiento {
    
    int ID_Movimiento;
    int ID_Producto;
    double Cantidad;
    String Concepto;
    private LocalDateTime fecha;
    String TipoMovimiento;
    
    public Movimiento(int ID_Movimiento, int ID_Producto, double Cantidad, String Concepto, String TipoMovimiento){
        
        this.ID_Movimiento = ID_Movimiento;
        this.ID_Producto = ID_Producto;
        this.Cantidad = Cantidad;
        this.Concepto = Concepto;
        this.fecha = LocalTimeNow();
        this.TipoMovimiento = TipoMovimiento;
        
    }
    
    public void obtenerMovimiento(){
        
        
        
    }

    private LocalDateTime LocalTimeNow() {

        return null;

    }
    
    
}
