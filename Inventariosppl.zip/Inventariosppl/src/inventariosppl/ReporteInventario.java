package inventariosppl;

import java.util.List;
import java.util.ArrayList;

public class ReporteInventario implements reportesInterface{
    
    private List<Inventario> inventarios;
    
    public ReporteInventario(){
        inventarios = new ArrayList<>();
    }

    @Override
    public void generarReporte() {
        System.out.println("--------------------------------------------");
        System.out.println();
        System.out.println("========= REPORTE DE >>> Inventarios <<< =========");
        System.out.println();
        System.out.println("--------------------------------------------");
        if(inventarios.isEmpty()){
            System.out.println("No hay productos dentro del inventario.");
        }else{
            for(Inventario i : inventarios){
                System.out.println("ID Producto: " + i.getID_Producto());
                System.out.println("Existencia Actual: " + i.getExistenciaActual());
                System.out.println("Existencia Mínima: " + i.ExistenciaMinima);
                if(i.getExistenciaActual() <= i.ExistenciaMinima){
                    System.out.println("--------------------------------------------");
                    System.out.println();
                    System.out.println("Estado: >>**ALERTA: BAJO STOCK**<<");
                    System.out.println();
                    System.out.println("--------------------------------------------");
                }else{
                     System.out.println("--------------------------------------------");
                    System.out.println();
                    System.out.println("Estado: >> Stock saludable <<");
                    System.out.println();
                    System.out.println("--------------------------------------------");
                }
            }
        }
    }

    void agregarInventario(Inventario inv) {
        this.inventarios.add(inv);
    }
    
}
