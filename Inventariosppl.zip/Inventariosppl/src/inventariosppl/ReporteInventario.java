/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariosppl;

import java.util.List;
import java.util.ArrayList;

public class ReporteInventario implements reportesInterface{
    
    private List<Inventario> inventarios;
    
    public ReporteInventario(){
        inventarios = new ArrayList<>();
    }

    @Override
    public void generarReporte() {
        
        
        
    }
    
}
