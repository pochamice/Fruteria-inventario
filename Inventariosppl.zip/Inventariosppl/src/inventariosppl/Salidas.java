
package inventariosppl;

public class Salidas extends Movimiento{

    public Salidas(int ID_Movimiento, int ID_Producto, double Cantidad, String Concepto, String TipoMovimiento, int par) {
        super(ID_Movimiento, ID_Producto, Cantidad, Concepto, TipoMovimiento);
    }
    
    public void registrarSalidas(Inventario inventario){
        
    obtenerMovimiento();
    inventario.actualizarStock(this.getCantidad() * -1);
    
    System.out.println("Salida registrada. Stock descontado para el producto " + this.getID_Producto());
        
    }
    
}
