/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariosppl;

/**
 *
 * @author Michelle
 */
public class Salidas extends Movimiento{
    
    public Salidas(int ID_Movimiento, int ID_Producto, double Cantidad, String Concepto, String TipoMovimiento) {
        super(ID_Movimiento, ID_Producto, Cantidad, Concepto, TipoMovimiento);
    }
    
    public void registrarSalidas(){
        
    }
    
}
