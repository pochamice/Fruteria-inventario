
package inventariosppl;


public interface reportesInterface {
    
    void generarReporte();
    
}
