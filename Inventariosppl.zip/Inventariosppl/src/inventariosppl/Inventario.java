/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariosppl;

public class Inventario {
    
    int ID_Producto;
    double ExistenciaActual;
    
    public Inventario(int ID_Producto, double ExistenciaActual){
        
        this.ID_Producto = ID_Producto;
        this.ExistenciaActual = ExistenciaActual;
        
    }
    
    void ObtenerExistencia(){
        
    }
    void validarStock(){
        
    }
    void actualizarStock(){
        
    }
    void modificar(){
        
    }
    void borrar(){
        
    }
    
}
