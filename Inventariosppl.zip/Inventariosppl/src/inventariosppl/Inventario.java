package inventariosppl;

public class Inventario {

    int ID_Producto;
    double ExistenciaActual;
    double ExistenciaMinima;

    public Inventario(int ID_Producto, double ExistenciaActual, double ExistenciaMinima) {

        this.ID_Producto = ID_Producto;
        this.ExistenciaActual = ExistenciaActual;
        this.ExistenciaMinima = ExistenciaMinima;
    }

    public int getID_Producto() {
        return ID_Producto;
    }

    public double getExistenciaActual() {
        return ExistenciaActual;
    }

    void ObtenerExistencia() {
        System.out.println("Producto ID: " + ID_Producto);
        System.out.println("Existencia actual del producto: " + ExistenciaActual);

    }

    void validarStock(Productos p) {

        if (ExistenciaActual <= ExistenciaMinima) {
            System.out.println("El producto " + ID_Producto + " esta por debajo del stock minimo. ");
            System.out.println("El stock minimo requerido es: " + Productos.getStockMin());
            System.out.println("Existencia actual: " + ExistenciaActual);
        } else {
            System.out.println("El stock del producto " + ID_Producto + " es adecuado. ");
        }
    }

    void actualizarStock(double cantidad) {
        ExistenciaActual += cantidad;
    }

    void modificar(double nuevaExistencia) {

        if (nuevaExistencia < 0) {
            System.out.println("No se puede asignar valores negativos.");
            return;
        } else {
            ExistenciaActual = nuevaExistencia;
            System.out.println("Se ha modificado la existencia correctamente. ");
        }

    }

    void borrar() {
        ExistenciaActual = 0;
        System.out.println("La existencia del producto ID " + ID_Producto + "ha sido borrada exitosamente. ");
    }

}
