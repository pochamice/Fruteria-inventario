
package inventariosppl;

import java.util.ArrayList;
import java.util.List;

public class ReporteMovimientos implements reportesInterface {

    private List<Entradas> entrada;
    private List<Salidas> salida;

    public ReporteMovimientos() {
        entrada = new ArrayList<>();
        salida = new ArrayList<>();
    }

    public void agregarEntrada(Entradas e) {
        this.entrada.add(e);
    }

    public void agregarSalida(Salidas s) {
        this.salida.add(s);
    }

    @Override
    public void generarReporte() {
        System.out.println("--------------------------------------------");
        System.out.println();
        System.out.println("========= REPORTE DE MOVIMIENTOS =========");
        System.out.println();
        System.out.println("--------------------------------------------");
        System.out.println();
        System.out.println(">>> Entradas. <<<");
        if (entrada.isEmpty()) {
            System.out.println("No hay entradas para mostrar.");
        } else {
            for(Entradas e : entrada){
            System.out.println("Id Movimiento: " + e.getID_Movimiento());
            System.out.println("ID Producto: " + e.getID_Producto());
            System.out.println("Cantidad: " + e.getCantidad());
            System.out.println("Concepto: " + e.getConcepto());
            System.out.println("Tipo: " + e.getTipoMovimiento());
            System.out.println("ID Proveedor: " + e.getID_Proveedor());
            System.out.println("-------------------------------");
            }
        }
        
        System.out.println();
        System.out.println(">>> Salidas. <<<");
        if (salida.isEmpty()) {
            System.out.println("No hay salidas para mostrar.");
        } else {
            for(Salidas e : salida){
            System.out.println("Id Movimiento: " + e.getID_Movimiento());
            System.out.println("ID Producto: " + e.getID_Producto());
            System.out.println("Cantidad: " + e.getCantidad());
            System.out.println("Concepto: " + e.getConcepto());
            System.out.println("Tipo: " + e.getTipoMovimiento());
            System.out.println("-------------------------------");
            }
        }
        
    }

}
