/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariosppl;

/**
 *
 * @author Michelle
 */
public class LoteProducto {
    
    int ID_Lote;
    int ID_Producto;
    String TipoDeLote;
    
    public LoteProducto(int ID_Lote, int ID_Producto, String TipoDeLote){
        
        this.ID_Lote = ID_Lote;
        this.ID_Producto = ID_Producto;
        this.TipoDeLote = TipoDeLote;
        
    }
    
    void obtenerLotesDispo(){
        
    }
    
}
