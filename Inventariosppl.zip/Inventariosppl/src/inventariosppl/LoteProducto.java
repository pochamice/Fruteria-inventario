/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariosppl;


public class LoteProducto {
    int ID_Lote;
    int ID_Producto;
    String TipoDeLote; 
    
    public LoteProducto(int ID_Lote, int ID_Producto, String TipoDeLote){
        try {
        if (ID_Lote <= 0 || ID_Producto <= 0) {
        throw new IllegalArgumentException ("Los ID deben ser mayores a 0");
            }
        if (TipoDeLote == null) {
        throw new IllegalArgumentException ("El tipo de lote no puede estar vacio");
            }
       
        this.ID_Lote = ID_Lote;
        this.ID_Producto = ID_Producto;
        this.TipoDeLote = TipoDeLote;
        } catch (IllegalArgumentException ex) {
            System.out.println("Error al obtener el lote: " + ex.getMessage());
        }
       
    }
   
    void obtenerLotesDispo(){
        System.out.println("Lote disponible: ");
        System.out.println("ID Lote: " + ID_Lote);
        System.out.println("ID Producto: " + ID_Producto);
        System.out.println("Tipo de lote: " + TipoDeLote);
    }
    
}
